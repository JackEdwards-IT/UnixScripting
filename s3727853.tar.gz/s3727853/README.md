# UnixScripting
Unix Admin A2 - Scripting

Jack Edwards - S3727853

Working Features Part B
------------------------
Requirment 1 - basic information info_basic.sh

Requirment 2 - basic information info_post.sh

Requirment 5 - Menu system menu_system.sh

Partially working
------------------------
Requirment 3 - find script find.sh

This script does not work correctly and I have given up on it.

Not implemented
------------------------

Requirment 4 - basic_profiler.sh

	I did not even try to implement this as the previous requirment was beyond me..
