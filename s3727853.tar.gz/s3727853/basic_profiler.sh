#!/bin/bash

#Created by Jack Edwards
#RMIT student number S3727853

printf "\e[4mBasic Profiler\e[0m\n"
